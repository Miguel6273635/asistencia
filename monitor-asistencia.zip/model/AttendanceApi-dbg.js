sap.ui.define([], function () {
  "use strict";

  /* global Promise */

  class AttendanceApiError extends Error {
    constructor(status, message, responseBody = "") {
      super(message);
      this.status = status;
      this.responseBody = responseBody;
      this.name = "AttendanceApiError";
    }
  }
  function trimSlashes(value) {
    return value.replace(/^\/+|\/+$/g, "");
  }
  const ATTENDANCE_SERVICE_PATH = "sap/opu/odata/sap/ZHMC_ATTENDANCE_MONITORING_SRV/";

  /**
   * Resuelve la URL del servicio con el mismo prefijo desde el que se sirve la
   * aplicación HTML5.
   *
   * En BAS la aplicación se abre desde /index.html o /test/flp.html y el proxy
   * escucha directamente en /sap. En el runtime HTML5 de BTP la aplicación se
   * publica bajo un segmento propio, por ejemplo:
   *
   * /<app-id>.mitsumonitorasistencia-0.4.0/index.html
   *
   * En ese caso la petición debe conservar ese segmento antes de /sap para que
   * el runtime encuentre el xs-app.json de esta aplicación y aplique la ruta a
   * la destination configurada.
   */
  function resolveDefaultServiceRoot() {
    if (typeof window === "undefined") {
      return `/${ATTENDANCE_SERVICE_PATH}`;
    }
    const pathname = window.location.pathname || "/";
    const directory = pathname.slice(0, pathname.lastIndexOf("/") + 1) || "/";
    const isLocalRoot = directory === "/";
    const isLocalPreview = directory === "/test/" || directory.endsWith("/test/");
    if (isLocalRoot || isLocalPreview) {
      return `/${ATTENDANCE_SERVICE_PATH}`;
    }
    return `${directory}${ATTENDANCE_SERVICE_PATH}`;
  }
  function normalizeServiceRoot(serviceRoot) {
    const cleanRoot = trimSlashes(serviceRoot);
    return `/${cleanRoot}/`;
  }
  function formatLiteral(value) {
    if (value instanceof Date) {
      return `datetime'${value.toISOString().replace(/\.\d{3}Z$/, "")}'`;
    }
    if (typeof value === "string") {
      return `'${value.replace(/'/g, "''")}'`;
    }
    return String(value);
  }
  function buildFilter(filters = []) {
    return filters.filter(filter => filter.value !== "").map(filter => `${filter.field} ${filter.operator ?? "eq"} ${formatLiteral(filter.value)}`).join(" and ");
  }
  function filtersForOverview(query) {
    const filters = [{
      field: "PeriodType",
      value: query.periodType
    }];
    if (query.referenceDate) {
      filters.push({
        field: "ReferenceDate",
        value: query.referenceDate
      });
    }
    if (query.zone) {
      filters.push({
        field: "Zone",
        value: query.zone
      });
    }
    if (query.scheduleCode) {
      filters.push({
        field: "ScheduleCode",
        value: query.scheduleCode
      });
    }
    if (query.status) {
      filters.push({
        field: "Status",
        value: query.status
      });
    }
    return filters;
  }
  class AttendanceApi {
    csrfToken = "";
    constructor(serviceRoot = resolveDefaultServiceRoot()) {
      this.serviceRoot = normalizeServiceRoot(serviceRoot);
      console.info("[Monitor][ODATA][SERVICE-ROOT]", this.serviceRoot);
    }
    async getCollection(entitySet, options = {}) {
      const url = this.buildUrl(entitySet, options);
      console.groupCollapsed(`[Monitor][ODATA][GET][${entitySet}]`);
      console.info("URL", url);
      console.info("Filtros", options.filters ?? []);
      console.info("Opciones", options);
      console.groupEnd();
      const response = await fetch(url, {
        method: "GET",
        credentials: "same-origin",
        headers: {
          Accept: "application/json"
        },
        signal: options.signal
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      const body = await response.json();
      const rows = body.d?.results ?? [];
      console.groupCollapsed(`[Monitor][ODATA][RAW-RESPONSE][${entitySet}] ${rows.length} fila(s)`);
      console.info(body);
      console.table(rows);
      console.groupEnd();
      return rows;
    }
    async getOverview(query, signal) {
      const options = {
        filters: filtersForOverview(query),
        signal
      };
      const [zones, indicators] = await Promise.all([this.getCollection("ZoneSummarySet", options), this.getCollection("CriticalIndicatorsSet", options)]);
      return {
        zones,
        indicators
      };
    }
    async getCenterSnapshot(periodType, centerOffice, signal) {
      const filters = [{
        field: "PeriodType",
        value: periodType
      }, {
        field: "CenterOffice",
        value: centerOffice
      }];
      const options = {
        filters,
        signal
      };
      const [indicators, scheduleDistribution, incidentTrend, schedules] = await Promise.all([this.getCollection("CriticalIndicatorsSet", options), this.getCollection("ScheduleDistributionSet", options), this.getCollection("IncidentTrendSet", options), this.getCollection("CatalogScheduleSet", {
        signal
      })]);
      return {
        indicators,
        scheduleDistribution,
        incidentTrend,
        schedules
      };
    }
    getAttendanceHistory(filters, signal) {
      return this.getCollection("AttendanceHistorySet", {
        filters,
        signal
      });
    }
    getDailyAbsences(signal) {
      return this.getCollection("DailyAbsencesSet", {
        signal
      });
    }
    getEmployees(filters = [], signal) {
      return this.getCollection("EmployeeSet", {
        filters,
        signal
      });
    }
    getSchedules(filters = [], signal) {
      return this.getCollection("CatalogScheduleSet", {
        filters,
        signal
      });
    }
    getPerformanceTrend(filters, signal) {
      return this.getCollection("PerformanceTrendSet", {
        filters,
        signal
      });
    }
    getGeneralMapLocations(filters = [], signal) {
      return this.getCollection("GeneralMapUbicationsSet", {
        filters,
        signal
      });
    }
    getProcessingJustifications(dateFrom, dateTo, signal) {
      return this.getCollection("ProcessingJustificationsSet", {
        filters: [{
          field: "DateFrom",
          value: dateFrom
        }, {
          field: "DateTo",
          value: dateTo
        }],
        signal
      });
    }
    getFourthLateReviews(dateFrom, dateTo, signal) {
      return this.getCollection("ProcessingDelaysSet", {
        filters: [{
          field: "DateFrom",
          value: dateFrom
        }, {
          field: "DateTo",
          value: dateTo
        }],
        signal
      }).then(rows => {
        const fourthLateRows = rows.filter(row => {
          const totalDelays = Number(String(row.TotalDelays ?? "").trim());
          return Number.isFinite(totalDelays) && totalDelays >= 4;
        });
        console.info("[Monitor][4TH-LATE][ELIGIBLE]", {
          dateFrom,
          dateTo,
          received: rows.length,
          eligible: fourthLateRows.length
        });
        return fourthLateRows;
      });
    }
    submitJustificationDecision(payload) {
      return this.postEntity("ProcessingJustificationsSet", payload, "JUSTIFICATION-DECISION");
    }
    submitFourthLateDecision(payload) {
      console.group("[Monitor][4TH-LATE][POST][REQUEST]");
      console.info("EntitySet", "ProcessingDelaysSet");
      console.info("Payload", payload);
      console.info("Payload JSON", JSON.stringify(payload, null, 2));
      console.table([payload]);
      console.groupEnd();

      // Break temporal solicitado para inspeccionar el POST antes de enviarlo.
      // Con DevTools abierto, continuar con F8 para ejecutar la petición.
      debugger;
      return this.postEntity("ProcessingDelaysSet", payload, "FOURTH-LATE-DECISION").then(response => {
        console.group("[Monitor][4TH-LATE][POST][RESPONSE]");
        console.info("Respuesta SAP", response);
        console.info("Respuesta JSON", JSON.stringify(response, null, 2));
        console.groupEnd();

        // Segunda pausa para inspeccionar la respuesta exitosa de SAP.
        debugger;
        const status = String(response.StatusRequest ?? "").trim().toUpperCase();
        if (status && status !== "OK") {
          throw new AttendanceApiError(200, String(response.MessageRequest ?? "SAP rechazó la decisión del 4.º retardo."), JSON.stringify(response));
        }
        return response;
      }).catch(error => {
        console.group("[Monitor][4TH-LATE][POST][ERROR]");
        console.error("Error", error);
        console.error("HTTP status", error.status);
        console.error("Response body", error.responseBody);
        console.groupEnd();

        // Tercera pausa para inspeccionar el body que SAP devolvió con error.
        debugger;
        throw error;
      });
    }
    async createAttendanceRecord(payload) {
      return this.postEntity("AttendanceRecordSet", payload, "ATTENDANCE-RECORD");
    }
    async postEntity(entitySet, payload, logName) {
      const url = `${this.serviceRoot}${entitySet}`;
      console.groupCollapsed(`[Monitor][ODATA][POST][${logName}]`);
      console.info("URL", url);
      console.info("Payload", payload);
      console.groupEnd();
      const response = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-CSRF-Token": await this.getCsrfToken()
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      if (response.status === 204) {
        return {};
      }
      const body = await response.json();
      console.groupCollapsed(`[Monitor][ODATA][RAW-RESPONSE][${logName}]`);
      console.info(body);
      console.groupEnd();
      return body.d ?? {};
    }
    async uploadEmployees(payload, entitySet = "EmployeesUploadSet") {
      if (!/^[A-Za-z0-9_]+$/.test(entitySet)) {
        throw new Error("El EntitySet de carga contiene caracteres no permitidos.");
      }
      const url = `${this.serviceRoot}${entitySet}`;
      console.groupCollapsed(`[Monitor][EMPLOYEE-UPLOAD][POST][${entitySet}]`);
      console.info("URL", url);
      console.info("Payload", payload);
      console.groupEnd();
      const response = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-CSRF-Token": await this.getCsrfToken()
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      if (response.status === 204) {
        return {};
      }
      const body = await response.json();
      console.groupCollapsed(`[Monitor][EMPLOYEE-UPLOAD][RAW-RESPONSE][${entitySet}]`);
      console.info(body);
      console.groupEnd();
      return body.d ?? {};
    }
    buildUrl(entitySet, options) {
      const params = new URLSearchParams();
      const filter = buildFilter(options.filters);
      if (filter) {
        params.set("$filter", filter);
      }
      if (options.select?.length) {
        params.set("$select", options.select.join(","));
      }
      if (options.orderBy?.length) {
        params.set("$orderby", options.orderBy.join(","));
      }
      if (Number.isInteger(options.top) && Number(options.top) > 0) {
        params.set("$top", String(options.top));
      }
      if (Number.isInteger(options.skip) && Number(options.skip) >= 0) {
        params.set("$skip", String(options.skip));
      }
      params.set("$format", "json");
      const query = params.toString().replace(/\+/g, "%20");
      return `${this.serviceRoot}${entitySet}?${query}`;
    }
    async getCsrfToken() {
      if (this.csrfToken) {
        return this.csrfToken;
      }
      const response = await fetch(this.serviceRoot, {
        method: "GET",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "X-CSRF-Token": "Fetch"
        }
      });
      if (!response.ok) {
        throw await this.toError(response, `No fue posible obtener el token CSRF: HTTP ${response.status}`);
      }
      const token = response.headers.get("X-CSRF-Token");
      if (!token) {
        throw new AttendanceApiError(response.status, "El servicio no devolvió un token CSRF.");
      }
      this.csrfToken = token;
      return token;
    }
    async toError(response, message) {
      const responseBody = await response.text();
      console.error("[Monitor][ODATA][ERROR]", {
        status: response.status,
        statusText: response.statusText,
        url: response.url,
        message,
        responseBody
      });
      return new AttendanceApiError(response.status, message, responseBody);
    }
  }
  AttendanceApi.AttendanceApiError = AttendanceApiError;
  return AttendanceApi;
});
//# sourceMappingURL=AttendanceApi-dbg.js.map

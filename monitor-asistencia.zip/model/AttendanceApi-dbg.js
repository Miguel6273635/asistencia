sap.ui.define([], function () {
  "use strict";

  /* global Promise */

  class AttendanceApiError extends Error {
    constructor(status, message, responseBody = "") {
      super(message);
      this.status = status;
      this.responseBody = responseBody;
      this.name = "AttendanceApiError";
    }
  }
  function trimSlashes(value) {
    return value.replace(/^\/+|\/+$/g, "");
  }
  function formatLiteral(value) {
    if (value instanceof Date) {
      return `datetime'${value.toISOString().replace(/\.\d{3}Z$/, "")}'`;
    }
    if (typeof value === "string") {
      return `'${value.replace(/'/g, "''")}'`;
    }
    return String(value);
  }
  function buildFilter(filters = []) {
    return filters.filter(filter => filter.value !== "").map(filter => `${filter.field} ${filter.operator ?? "eq"} ${formatLiteral(filter.value)}`).join(" and ");
  }
  function filtersForOverview(query) {
    const filters = [{
      field: "PeriodType",
      value: query.periodType
    }];
    if (query.referenceDate) {
      filters.push({
        field: "ReferenceDate",
        value: query.referenceDate
      });
    }
    if (query.zone) {
      filters.push({
        field: "Zone",
        value: query.zone
      });
    }
    if (query.scheduleCode) {
      filters.push({
        field: "ScheduleCode",
        value: query.scheduleCode
      });
    }
    if (query.status) {
      filters.push({
        field: "Status",
        value: query.status
      });
    }
    return filters;
  }
  class AttendanceApi {
    csrfToken = "";
    constructor(serviceRoot = "sap/opu/odata/sap/ZHMC_ATTENDANCE_MONITORING_SRV/") {
      /*
       * CAMBIO PARA SAP BTP / WORK ZONE
       *
       * Antes el servicio siempre comenzaba en:
       *
       * /sap/opu/odata/sap/...
       *
       * Eso hacía que en el Launchpad la petición
       * utilizara la raíz del dominio.
       *
       * Ahora resolvemos la URL desde la ubicación
       * del módulo SAPUI5.
       */

      const appModuleUrl = sap.ui.require.toUrl("com/mitsu/monitorasistencia/");
      const appBaseUrl = new URL(appModuleUrl.endsWith("/") ? appModuleUrl : appModuleUrl + "/", window.location.href);
      const normalizedServiceRoot = trimSlashes(serviceRoot) + "/";
      this.serviceRoot = new URL(normalizedServiceRoot, appBaseUrl).toString();
      console.info("[Monitor][ODATA][APP-BASE]", appBaseUrl.toString());
      console.info("[Monitor][ODATA][SERVICE-ROOT]", this.serviceRoot);
    }
    async getCollection(entitySet, options = {}) {
      const url = this.buildUrl(entitySet, options);
      console.groupCollapsed(`[Monitor][ODATA][GET][${entitySet}]`);
      console.info("URL", url);
      console.info("Filtros", options.filters ?? []);
      console.info("Opciones", options);
      console.groupEnd();
      const response = await fetch(url, {
        method: "GET",
        credentials: "same-origin",
        headers: {
          Accept: "application/json"
        },
        signal: options.signal
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      const body = await response.json();
      const rows = body.d?.results ?? [];
      console.groupCollapsed(`[Monitor][ODATA][RAW-RESPONSE][${entitySet}] ${rows.length} fila(s)`);
      console.info(body);
      console.table(rows);
      console.groupEnd();
      return rows;
    }
    async getOverview(query, signal) {
      const options = {
        filters: filtersForOverview(query),
        signal
      };
      const [zones, indicators] = await Promise.all([this.getCollection("ZoneSummarySet", options), this.getCollection("CriticalIndicatorsSet", options)]);
      return {
        zones,
        indicators
      };
    }
    async getCenterSnapshot(periodType, centerOffice, signal) {
      const filters = [{
        field: "PeriodType",
        value: periodType
      }, {
        field: "CenterOffice",
        value: centerOffice
      }];
      const options = {
        filters,
        signal
      };
      const [indicators, scheduleDistribution, incidentTrend, schedules] = await Promise.all([this.getCollection("CriticalIndicatorsSet", options), this.getCollection("ScheduleDistributionSet", options), this.getCollection("IncidentTrendSet", options), this.getCollection("CatalogScheduleSet", {
        signal
      })]);
      return {
        indicators,
        scheduleDistribution,
        incidentTrend,
        schedules
      };
    }
    getAttendanceHistory(filters, signal) {
      return this.getCollection("AttendanceHistorySet", {
        filters,
        signal
      });
    }
    getEmployees(filters = [], signal) {
      return this.getCollection("EmployeeSet", {
        filters,
        signal
      });
    }
    getSchedules(filters = [], signal) {
      return this.getCollection("CatalogScheduleSet", {
        filters,
        signal
      });
    }
    getPerformanceTrend(filters, signal) {
      return this.getCollection("PerformanceTrendSet", {
        filters,
        signal
      });
    }
    getGeneralMapLocations(filters = [], signal) {
      return this.getCollection("GeneralMapUbicationsSet", {
        filters,
        signal
      });
    }
    getProcessingJustifications(dateFrom, dateTo, signal) {
      return this.getCollection("ProcessingJustificationsSet", {
        filters: [{
          field: "DateFrom",
          value: dateFrom
        }, {
          field: "DateTo",
          value: dateTo
        }],
        signal
      });
    }
    submitJustificationDecision(payload) {
      return this.postEntity("ProcessingJustificationsSet", payload, "JUSTIFICATION-DECISION");
    }
    async createAttendanceRecord(payload) {
      return this.postEntity("AttendanceRecordSet", payload, "ATTENDANCE-RECORD");
    }
    async postEntity(entitySet, payload, logName) {
      const url = `${this.serviceRoot}${entitySet}`;
      console.groupCollapsed(`[Monitor][ODATA][POST][${logName}]`);
      console.info("URL", url);
      console.info("Payload", payload);
      console.groupEnd();
      const response = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-CSRF-Token": await this.getCsrfToken()
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      if (response.status === 204) {
        return {};
      }
      const body = await response.json();
      console.groupCollapsed(`[Monitor][ODATA][RAW-RESPONSE][${logName}]`);
      console.info(body);
      console.groupEnd();
      return body.d ?? {};
    }
    async uploadEmployees(payload, entitySet = "EmployeesUploadSet") {
      if (!/^[A-Za-z0-9_]+$/.test(entitySet)) {
        throw new Error("El EntitySet de carga contiene caracteres no permitidos.");
      }
      const url = `${this.serviceRoot}${entitySet}`;
      console.groupCollapsed(`[Monitor][EMPLOYEE-UPLOAD][POST][${entitySet}]`);
      console.info("URL", url);
      console.info("Payload", payload);
      console.groupEnd();
      const response = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          "X-CSRF-Token": await this.getCsrfToken()
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw await this.toError(response, `${entitySet} respondió con HTTP ${response.status}`);
      }
      if (response.status === 204) {
        return {};
      }
      const body = await response.json();
      console.groupCollapsed(`[Monitor][EMPLOYEE-UPLOAD][RAW-RESPONSE][${entitySet}]`);
      console.info(body);
      console.groupEnd();
      return body.d ?? {};
    }
    buildUrl(entitySet, options) {
      const params = new URLSearchParams();
      const filter = buildFilter(options.filters);
      if (filter) {
        params.set("$filter", filter);
      }
      if (options.select?.length) {
        params.set("$select", options.select.join(","));
      }
      if (options.orderBy?.length) {
        params.set("$orderby", options.orderBy.join(","));
      }
      if (Number.isInteger(options.top) && Number(options.top) > 0) {
        params.set("$top", String(options.top));
      }
      if (Number.isInteger(options.skip) && Number(options.skip) >= 0) {
        params.set("$skip", String(options.skip));
      }
      params.set("$format", "json");
      const query = params.toString().replace(/\+/g, "%20");
      return `${this.serviceRoot}${entitySet}?${query}`;
    }
    async getCsrfToken() {
      if (this.csrfToken) {
        return this.csrfToken;
      }
      const response = await fetch(this.serviceRoot, {
        method: "GET",
        credentials: "same-origin",
        headers: {
          Accept: "application/json",
          "X-CSRF-Token": "Fetch"
        }
      });
      if (!response.ok) {
        throw await this.toError(response, `No fue posible obtener el token CSRF: HTTP ${response.status}`);
      }
      const token = response.headers.get("X-CSRF-Token");
      if (!token) {
        throw new AttendanceApiError(response.status, "El servicio no devolvió un token CSRF.");
      }
      this.csrfToken = token;
      return token;
    }
    async toError(response, message) {
      const responseBody = await response.text();
      console.error("[Monitor][ODATA][ERROR]", {
        status: response.status,
        statusText: response.statusText,
        url: response.url,
        message,
        responseBody
      });
      return new AttendanceApiError(response.status, message, responseBody);
    }
  }
  AttendanceApi.AttendanceApiError = AttendanceApiError;
  return AttendanceApi;
});
//# sourceMappingURL=AttendanceApi-dbg.js.map

sap.ui.define(["com/mitsu/monitorasistencia/thirdparty/xlsx"],function(t){"use strict";return t&&t.default?t.default:t});
//# sourceMappingURL=EmployeeExcel.js.map
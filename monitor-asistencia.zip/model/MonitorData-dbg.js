sap.ui.define(["./AttendanceApi"], function (__AttendanceApi) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  /* global Promise */
  const AttendanceApi = _interopRequireDefault(__AttendanceApi);
  function text(value) {
    if (value === null || value === undefined) {
      return "";
    }
    if (typeof value === "string") {
      return value.trim();
    }
    if (typeof value === "number" || typeof value === "boolean" || typeof value === "bigint") {
      return value.toString().trim();
    }
    return value instanceof Date ? value.toISOString() : "";
  }
  function number(value) {
    const parsed = Number(text(value).replace(",", "."));
    return Number.isFinite(parsed) ? parsed : 0;
  }
  function bool(value) {
    return value === true || text(value).toLowerCase() === "true" || text(value) === "X";
  }
  function slug(value) {
    return text(value).replace(/^ZONA\s+/i, "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "sin-zona";
  }
  const OPERATIONAL_ZONES = [{
    id: "centro",
    name: "Zona Centro",
    aliases: ["CENTRO", "ZC"]
  }, {
    id: "norte",
    name: "Zona Norte",
    aliases: ["NORTE", "ZN"]
  }, {
    id: "sur",
    name: "Zona Sur",
    aliases: ["SUR", "ZS"]
  }, {
    id: "este",
    name: "Zona Este",
    aliases: ["ESTE", "ZE"]
  }, {
    id: "oeste",
    name: "Zona Oeste",
    aliases: ["OESTE", "ZO"]
  }];
  function normalizedZoneToken(value) {
    return text(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/^ZONA\s+/, "").trim();
  }
  function operationalZone(value) {
    const token = normalizedZoneToken(value);
    return OPERATIONAL_ZONES.find(zone => zone.id.toUpperCase() === token || zone.name.replace(/^Zona\s+/i, "").toUpperCase() === token || zone.aliases.indexOf(token) >= 0);
  }
  function operationalZoneId(value) {
    return operationalZone(value)?.id || "sin-zona";
  }
  function displayZone(value) {
    return operationalZone(value)?.name || "Sin zona";
  }
  function displayDate(value) {
    const raw = text(value).replace(/-/g, "");
    return /^\d{8}$/.test(raw) ? `${raw.slice(6, 8)}/${raw.slice(4, 6)}/${raw.slice(0, 4)}` : "";
  }
  function compactDate(value) {
    return text(value).replace(/[^0-9]/g, "").slice(0, 8);
  }
  function usableTime(value) {
    const time = text(value);
    return !time || /^00:00(?::00)?$/.test(time) ? "—" : time.slice(0, 5);
  }
  function durationTime(value) {
    const match = /^PT(\d{1,2})H(\d{1,2})M/.exec(text(value));
    return match ? `${match[1].padStart(2, "0")}:${match[2].padStart(2, "0")}` : "";
  }
  function durationMinutes(value) {
    const match = /^PT(\d{1,2})H(\d{1,2})M/.exec(text(value));
    return match ? Number(match[1]) * 60 + Number(match[2]) : null;
  }
  function inferScheduleType(row) {
    const supplied = text(row.ScheduleType);
    if (supplied) {
      return supplied;
    }
    const start = durationMinutes(row.WorkInit);
    const end = durationMinutes(row.WorkEnd);
    const detail = text(row.ScheduleDetail).toUpperCase();
    const timePairs = Array.from(detail.matchAll(/(\d{2}):\d{2}-(\d{2}):\d{2}/g));
    const differentStarts = new Set(timePairs.map(match => match[1])).size > 1;
    if (differentStarts) {
      return "Mixto";
    }
    if (start !== null && start >= 20 * 60 || end !== null && end <= 8 * 60 && start !== null && start > end) {
      return "Nocturno";
    }
    if (start !== null && start >= 12 * 60) {
      return "Vespertino";
    }
    if (/\b[SD]\b/.test(detail) && !/\bL[-–]/.test(detail)) {
      return "Fin de semana";
    }
    return "Diurno";
  }
  function isOutsideZone(row) {
    const geoStatus = [row.GeoStatus, row.GeoStatusDescripcion, row.GeoStatusDescription, row.LocationStatus, row.DayStatus].map(value => text(value).toUpperCase()).filter(Boolean).join(" ");
    const explicitOutside = bool(row.IsOutOfZone) || bool(row.OutOfZone) || /(^|\s)(OUT|OUTSIDE)(\s|$)|FUERA(?:\s+DE)?\s+ZONA|FUERA\s+DE\s+GEOCERCA|OUT_OF_ZONE/.test(geoStatus);
    const explicitInside = /(^|\s)IN(?:SIDE)?(\s|$)|DENTRO(?:\s+DE)?\s+(?:ZONA|GEOCERCA)/.test(geoStatus);
    const distanceText = text(row.DistanceMeters || row.Distance || row.DistanceFromCenter);
    const hasDistance = distanceText !== "" && Number.isFinite(Number(distanceText.replace(",", ".")));
    const outsideByDistance = hasDistance && Number(distanceText.replace(",", ".")) > 2;
    return explicitOutside || !explicitInside && outsideByDistance;
  }
  function attendanceStatus(row) {
    if (isOutsideZone(row)) {
      return "Fuera de zona";
    }
    const raw = text(row.DayStatus).toUpperCase();
    const hasEntry = usableTime(row.P10Time) !== "—";
    const hasExit = usableTime(row.P20Time) !== "—";
    const hasOtherMark = [row.P15Time, row.P25Time, row.P20Time].some(value => usableTime(value) !== "—");
    const backendMarksAbsent = bool(row.IsAbsent) || raw === "AUSENTE";
    const backendMarksIncomplete = bool(row.IsIncomplete) || raw === "INCOMPLETO";

    // Una ausencia requiere que no exista ninguna marcación válida. SAP puede
    // enviar IsAbsent/DayStatus=AUSENTE aun cuando existe P10 u otro evento.
    if (backendMarksIncomplete) {
      return "Incompleto";
    }
    if (backendMarksAbsent && hasEntry) {
      if (bool(row.IsLate)) {
        return "Retardo";
      }
      return hasExit ? "Presente" : "Incompleto";
    }
    if (backendMarksAbsent && hasOtherMark) {
      return "Incompleto";
    }
    if (backendMarksAbsent) {
      return "Ausente";
    }
    const known = {
      PRESENTE: "Presente",
      RETARDO: "Retardo",
      AUSENTE: "Ausente",
      INCOMPLETO: "Incompleto"
    };
    if (known[raw]) {
      return known[raw];
    }
    return usableTime(row.P10Time) !== "—" ? bool(row.IsLate) ? "Retardo" : "Presente" : "Ausente";
  }
  function risk(inefficiency, supplied) {
    const backend = text(supplied);
    if (backend) {
      return {
        text: backend,
        state: /alto|crit/i.test(backend) ? "Error" : /aten|medio/i.test(backend) ? "Warning" : "Success"
      };
    }
    if (inefficiency >= 25) {
      return {
        text: "Riesgo alto",
        state: "Error"
      };
    }
    if (inefficiency >= 15) {
      return {
        text: "Atención",
        state: "Warning"
      };
    }
    return {
      text: "Riesgo menor",
      state: "Success"
    };
  }
  function mapSchedules(rows, activeScheduleCount = 0) {
    const summaryMarksCatalogActive = activeScheduleCount > 0 && activeScheduleCount === rows.length;
    return rows.map(row => {
      const code = text(row.Rule) || text(row.Schedule);
      const start = durationTime(row.WorkInit);
      const end = durationTime(row.WorkEnd);
      const detail = text(row.ScheduleDetail) || [start, end].filter(Boolean).join("–");
      return {
        id: `schedule-${slug(code)}`,
        code,
        name: text(row.Schedule) || code,
        type: inferScheduleType(row),
        shortDescription: detail,
        description: [text(row.DescriptionWork), detail].filter(Boolean).join(" · "),
        assigned: number(row.EvaluatedCount),
        present: number(row.PresentCount),
        absent: number(row.AbsenceCount),
        coverage: number(row.CoveragePct),
        active: summaryMarksCatalogActive || text(row.Status).toUpperCase() !== "INACTIVO",
        sourceStatus: text(row.Status),
        rules: []
      };
    });
  }
  const REGISTER_TIME_FIELDS = {
    P10: "P10Time",
    P15: "P15Time",
    P25: "P25Time",
    P20: "P20Time"
  };
  function firstNonEmpty(rows, field) {
    const row = rows.find(candidate => text(candidate[field]) !== "");
    return row ? row[field] : "";
  }
  function firstUsableTime(rows, field, registerType) {
    const aggregateRow = rows.find(candidate => usableTime(candidate[field]) !== "—");
    if (aggregateRow) {
      return aggregateRow[field];
    }
    const eventRow = rows.find(candidate => text(candidate.RegisterType).toUpperCase() === registerType && usableTime(candidate.EnterHour) !== "—");
    return eventRow ? eventRow.EnterHour : "";
  }
  function combinedText(rows, field) {
    return Array.from(new Set(rows.map(row => text(row[field])).filter(Boolean))).join(" ");
  }
  function consolidatedDayStatus(rows) {
    const statuses = rows.map(row => text(row.DayStatus).toUpperCase());
    const priority = ["INCOMPLETO", "RETARDO", "PRESENTE", "AUSENTE"];
    return priority.find(status => statuses.includes(status)) || statuses.find(Boolean) || "";
  }

  /**
   * AttendanceHistorySet devuelve una fila por marcación (P10, P15, P25 y P20).
   * La pantalla de Registros representa jornadas, por lo que todas las filas del
   * mismo empleado y fecha deben consolidarse antes de calcular KPIs y estatus.
   */
  function consolidateAttendanceHistory(rows) {
    const groups = new Map();
    rows.forEach((row, index) => {
      const personalNumber = text(row.PersonalNumber);
      const workDate = compactDate(row.WorkDate || row.EnterDate);
      const key = personalNumber && workDate ? `${personalNumber}|${workDate}` : `__unkeyed__|${index}`;
      const group = groups.get(key) || [];
      group.push(row);
      groups.set(key, group);
    });
    return Array.from(groups.values()).map(group => {
      if (group.length === 1) {
        return group[0];
      }
      const merged = {
        ...group[0]
      };
      Object.entries(REGISTER_TIME_FIELDS).forEach(([registerType, field]) => {
        merged[field] = firstUsableTime(group, field, registerType);
      });
      ["FullName", "Email", "CenterOffice", "CenterCode", "Zone", "Schedule", "ScheduleDescription", "ScheduleDetail", "NetHours", "DistanceMeters", "StatusReq", "Justification", "JustificationText"].forEach(field => {
        merged[field] = firstNonEmpty(group, field);
      });
      merged.DayStatus = consolidatedDayStatus(group);
      merged.IsLate = group.some(row => bool(row.IsLate));
      merged.IsAbsent = group.some(row => bool(row.IsAbsent));
      merged.IsIncomplete = group.some(row => bool(row.IsIncomplete));
      merged.IsEarlyExit = group.some(row => bool(row.IsEarlyExit) || bool(row.EarlyExit) || bool(row.IsEarly));
      const outsideRow = group.find(row => isOutsideZone(row));
      const insideRow = group.find(row => {
        const status = [row.GeoStatus, row.GeoStatusDescripcion, row.GeoStatusDescription, row.LocationStatus].map(value => text(value).toUpperCase()).filter(Boolean).join(" ");
        return /(^|\s)IN(?:SIDE)?(\s|$)|DENTRO(?:\s+DE)?\s+(?:DEL\s+RANGO|ZONA|GEOCERCA)/.test(status);
      });
      const geoRow = outsideRow || insideRow;
      merged.IsOutOfZone = Boolean(outsideRow);
      if (geoRow) {
        merged.GeoStatus = text(geoRow.GeoStatus) || (outsideRow ? "OUT" : "IN");
        merged.GeoStatusDescripcion = text(geoRow.GeoStatusDescripcion || geoRow.GeoStatusDescription) || (outsideRow ? "Registro fuera de rango" : "Registro dentro del rango");
        merged.DistanceMeters = firstNonEmpty([geoRow].concat(group), "DistanceMeters");
      }
      merged.Observation = combinedText(group, "Observation");
      merged.Message = combinedText(group, "Message");
      return merged;
    });
  }
  function mapRecords(rows, schedules) {
    const schedulesByCode = new Map(schedules.map(schedule => [text(schedule.code), schedule]));
    return consolidateAttendanceHistory(rows).map(row => {
      const personalNumber = text(row.PersonalNumber);
      const centerCode = text(row.CenterCode);
      const scheduleCode = text(row.Schedule);
      const schedule = schedulesByCode.get(scheduleCode) || {};
      const distance = text(row.DistanceMeters);
      return {
        id: `record-${personalNumber}-${text(row.WorkDate)}`,
        employeeId: `employee-${personalNumber}`,
        employee: text(row.FullName) || personalNumber,
        date: displayDate(row.WorkDate),
        dateISO: text(row.WorkDate),
        workDate: text(row.WorkDate),
        center: text(row.CenterOffice) || centerCode,
        centerCode,
        centerId: centerCode.toLowerCase(),
        zoneId: operationalZoneId(row.Zone),
        shift: text(row.ScheduleDescription) || text(schedule.name) || scheduleCode,
        scheduleId: `schedule-${slug(scheduleCode)}`,
        scheduled: text(row.ScheduleDetail) || text(schedule.shortDescription),
        entry: usableTime(row.P10Time),
        mealCheckOut: usableTime(row.P15Time),
        mealCheckIn: usableTime(row.P25Time),
        exit: usableTime(row.P20Time),
        hours: text(row.NetHours) || "0:00",
        distanceMeters: distance ? number(distance) : null,
        status: attendanceStatus(row),
        dayStatus: text(row.DayStatus),
        isLate: bool(row.IsLate),
        isAbsent: bool(row.IsAbsent),
        isIncomplete: bool(row.IsIncomplete),
        isOutOfZone: isOutsideZone(row),
        isEarlyExit: bool(row.IsEarlyExit) || bool(row.EarlyExit) || bool(row.IsEarly),
        observation: text(row.Observation),
        message: text(row.Message),
        justification: text(row.Justification) || text(row.JustificationText) || text(row.Message),
        approvalStatus: text(row.StatusReq),
        geoStatus: text(row.GeoStatus),
        geoStatusDescription: text(row.GeoStatusDescripcion)
      };
    });
  }
  function mapAttendanceRecords(rows, schedules = []) {
    return mapRecords(rows, schedules);
  }
  function mapEmployees(rows, history) {
    const employees = new Map();
    rows.forEach(row => {
      const personalNumber = text(row.PersonalNumber);
      if (!personalNumber) {
        return;
      }
      const score = (text(row.Zone) ? 8 : 0) + (/^ML\d+/i.test(text(row.CenterCode)) ? 6 : 0) + (/^Z\d+/i.test(text(row.ScheduleCode)) ? 5 : 0) + (text(row.ScheduleDetail) ? 3 : 0) + (text(row.Hourly) ? 2 : 0) + (text(row.RelationJob) ? 2 : 0) + (text(row.Email) ? 1 : 0);
      const candidate = {
        id: `employee-${personalNumber}`,
        number: personalNumber,
        PersonnelNumber: personalNumber,
        name: text(row.FullName) || personalNumber,
        initials: text(row.FullName).split(/\s+/).filter(Boolean).slice(0, 2).map(part => part.charAt(0)).join(""),
        centerId: text(row.CenterCode).toLowerCase(),
        center: text(row.CenterOffice),
        centerCode: text(row.CenterCode) || text(row.PersonnelArea),
        zoneId: operationalZoneId(row.Zone),
        shift: text(row.Hourly) || text(row.Shift),
        scheduleId: `schedule-${slug(row.ScheduleCode)}`,
        scheduleCode: text(row.ScheduleCode),
        scheduleName: text(row.Hourly) || text(row.ScheduleCode),
        scheduleDescription: text(row.ScheduleDetail),
        role: text(row.Position) || text(row.Role) || "Colaborador",
        status: text(row.DescriptionStatus),
        relationJob: text(row.RelationJob),
        relationJobDescription: text(row.RelationJobDescription),
        active: text(row.Status) !== "0",
        email: text(row.Email),
        lastUpdate: text(row.LastUpdate),
        HireDate: text(row.HireDate),
        Position: text(row.Position),
        PersonnelArea: text(row.PersonnelArea) || text(row.CenterCode),
        EmployeeGroup: text(row.EmployeeGroup),
        EmployeeSubgroup: text(row.EmployeeSubgroup),
        FirstName: text(row.FirstName) || text(row.FullName),
        LastName: text(row.LastName),
        BirthDate: text(row.BirthDate),
        Language: text(row.Language),
        BirthCountry: text(row.BirthCountry),
        Gender: text(row.Gender),
        PersonnelSubarea: text(row.PersonnelSubarea) || text(row.Base),
        AttendanceChannel: text(row.AttendanceChannel) || text(row.Chanel),
        Zone: text(row.Zone),
        City: text(row.City),
        Region: text(row.Region),
        Municipality: text(row.Municipality),
        Country: text(row.Country),
        ResidenceType: text(row.ResidenceType),
        Schedule: text(row.ScheduleCode) || text(row.Schedule),
        Email: text(row.Email),
        _score: score
      };
      const existing = employees.get(personalNumber);
      if (!existing || number(candidate._score) > number(existing._score)) {
        employees.set(personalNumber, Object.assign({}, existing || {}, candidate));
      } else {
        ["email", "role", "lastUpdate", "scheduleDescription", "relationJob", "relationJobDescription"].forEach(property => {
          if (!text(existing[property]) && text(candidate[property])) {
            existing[property] = candidate[property];
          }
        });
      }
    });
    history.forEach(row => {
      const personalNumber = text(row.PersonalNumber);
      const existing = employees.get(personalNumber);
      if (existing) {
        if (!existing.centerId) {
          existing.centerId = text(row.CenterCode).toLowerCase();
        }
        if (!existing.center) {
          existing.center = text(row.CenterOffice);
        }
        if (existing.zoneId === "sin-zona") {
          existing.zoneId = operationalZoneId(row.Zone);
        }
        if (existing.scheduleId === "schedule-sin-zona") {
          existing.scheduleId = `schedule-${slug(row.Schedule)}`;
        }
        return;
      }
      employees.set(personalNumber, {
        id: `employee-${personalNumber}`,
        number: personalNumber,
        PersonnelNumber: personalNumber,
        name: text(row.FullName) || personalNumber,
        initials: text(row.FullName).split(/\s+/).filter(Boolean).slice(0, 2).map(part => part.charAt(0)).join(""),
        centerId: text(row.CenterCode).toLowerCase(),
        center: text(row.CenterOffice),
        zoneId: operationalZoneId(row.Zone),
        shift: text(row.ScheduleDescription),
        scheduleId: `schedule-${slug(row.Schedule)}`,
        scheduleName: text(row.Schedule),
        role: "Colaborador",
        status: "Activo",
        active: true,
        HireDate: text(row.HireDate),
        Position: text(row.Position),
        PersonnelArea: text(row.PersonnelArea) || text(row.CenterCode),
        EmployeeGroup: text(row.EmployeeGroup),
        EmployeeSubgroup: text(row.EmployeeSubgroup),
        FirstName: text(row.FirstName) || text(row.FullName),
        LastName: text(row.LastName),
        BirthDate: text(row.BirthDate),
        Language: text(row.Language),
        BirthCountry: text(row.BirthCountry),
        Gender: text(row.Gender),
        PersonnelSubarea: text(row.PersonnelSubarea) || text(row.Base),
        AttendanceChannel: text(row.AttendanceChannel) || text(row.Chanel),
        Zone: text(row.Zone),
        City: text(row.City),
        Region: text(row.Region),
        Municipality: text(row.Municipality),
        Country: text(row.Country),
        ResidenceType: text(row.ResidenceType),
        Schedule: text(row.Schedule) || text(row.ScheduleCode),
        Email: text(row.Email)
      });
    });
    return Array.from(employees.values()).map(employee => {
      const result = Object.assign({}, employee);
      delete result._score;
      return result;
    });
  }
  function mapCenters(rows, history, employees) {
    const centers = new Map();
    rows.forEach(row => {
      const code = text(row.CenterCode);
      if (!code) {
        return;
      }
      const employee = employees.find(item => text(item.centerId) === code.toLowerCase() && text(item.zoneId) !== "sin-zona");
      const zone = text(row.Zone) || text(employee?.zoneId);
      centers.set(code, {
        id: code.toLowerCase(),
        name: text(row.CenterOffice) || code,
        code,
        zoneId: operationalZoneId(zone),
        zone: displayZone(zone),
        users: number(row.UsersCount),
        present: number(row.PresentCount),
        late: number(row.LateCount),
        absent: number(row.AbsenceCount),
        outside: number(row.OutOfZoneCount),
        attendance: number(row.AttendancePct),
        inefficiency: number(row.InefficiencyPct),
        incidents: number(row.IncidentCount),
        evaluated: number(row.EvaluatedCount),
        source: "sap",
        active: text(row.CenterStatus).toUpperCase() !== "INACTIVO"
      });
    });
    history.forEach(row => {
      const code = text(row.CenterCode);
      if (!code) {
        return;
      }
      const existing = centers.get(code);
      if (existing) {
        if (existing.zoneId === "sin-zona") {
          existing.zoneId = operationalZoneId(row.Zone);
          existing.zone = displayZone(row.Zone);
        }
        return;
      }
      centers.set(code, {
        id: code.toLowerCase(),
        name: text(row.CenterOffice) || code,
        code,
        zoneId: operationalZoneId(row.Zone),
        zone: displayZone(row.Zone),
        users: 0,
        present: 0,
        late: 0,
        absent: 0,
        attendance: 0,
        evaluated: 0,
        source: "sap",
        active: true
      });
    });
    employees.forEach(employee => {
      const code = text(employee.centerId).toUpperCase();
      if (!/^ML\d+/i.test(code) || centers.has(code)) {
        return;
      }
      centers.set(code, {
        id: code.toLowerCase(),
        name: text(employee.center) || code,
        code,
        zoneId: operationalZoneId(employee.zoneId),
        zone: displayZone(employee.zoneId),
        users: 0,
        present: 0,
        late: 0,
        absent: 0,
        outside: 0,
        attendance: 0,
        inefficiency: 0,
        incidents: 0,
        evaluated: 0,
        source: "sap",
        active: true
      });
    });
    return Array.from(centers.values());
  }
  function coordinate(value, longitude = false) {
    const raw = text(value).replace(",", ".");
    if (!raw) {
      return null;
    }
    const trailingNegative = /-$/.test(raw);
    const parsed = Number(raw.replace(/-$/, ""));
    if (!Number.isFinite(parsed)) {
      return null;
    }
    const normalized = trailingNegative ? -Math.abs(parsed) : longitude && parsed > 0 ? -parsed : parsed;
    if (!longitude && Math.abs(normalized) > 90 || longitude && Math.abs(normalized) > 180) {
      return null;
    }
    return normalized;
  }
  function distanceMeters(latitudeA, longitudeA, latitudeB, longitudeB) {
    const radians = degrees => degrees * Math.PI / 180;
    const latitudeDelta = radians(latitudeB - latitudeA);
    const longitudeDelta = radians(longitudeB - longitudeA);
    const a = Math.sin(latitudeDelta / 2) ** 2 + Math.cos(radians(latitudeA)) * Math.cos(radians(latitudeB)) * Math.sin(longitudeDelta / 2) ** 2;
    return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }
  function mapGeofenceStatus(row, latitudeEmployee, longitudeEmployee, latitudeCenter, longitudeCenter) {
    const rawStatus = [row.GeoStatus, row.GeoStatusDescripcion, row.GeoStatusDescription, row.LocationStatus].map(text).filter(Boolean).join(" ").toUpperCase();
    const outsideFlag = /^(X|TRUE|1|YES|SI|SÍ)$/i.test(text(row.IsOutOfZone || row.OutOfZone));
    const insideFlag = /^(X|TRUE|1|YES|SI|SÍ)$/i.test(text(row.IsInsideZone || row.InsideZone));
    const backendDistance = number(row.DistanceMeters || row.Distance || row.DistanceFromCenter);
    const calculatedDistance = latitudeEmployee !== null && longitudeEmployee !== null && latitudeCenter !== null && longitudeCenter !== null ? distanceMeters(latitudeEmployee, longitudeEmployee, latitudeCenter, longitudeCenter) : null;
    const effectiveDistance = backendDistance > 0 ? backendDistance : calculatedDistance;
    const allowedRadius = Math.max(0, number(row.RadiusMeters || row.AllowedRadius || row.Radius || row.RadioCoordenadas || row.Radio)) || 2;
    if (outsideFlag || /OUT(?:SIDE)?|FUERA|OUT_OF_ZONE/.test(rawStatus)) {
      return {
        label: "Fuera de zona",
        state: "Error",
        type: "Error",
        distance: effectiveDistance
      };
    }
    if (insideFlag || /(^|\s)IN(?:SIDE)?($|\s)|DENTRO/.test(rawStatus)) {
      return {
        label: "Dentro de zona",
        state: "Success",
        type: "Success",
        distance: effectiveDistance
      };
    }
    if (effectiveDistance !== null) {
      const outside = effectiveDistance > allowedRadius;
      return {
        label: outside ? "Fuera de zona" : "Dentro de zona",
        state: outside ? "Error" : "Success",
        type: outside ? "Error" : "Success",
        distance: effectiveDistance
      };
    }
    return {
      label: "Sin información de zona",
      state: "None",
      type: "Default",
      distance: null
    };
  }
  function separateOverlappingPersonnel(personnel) {
    const groups = new Map();
    personnel.forEach(person => {
      const key = text(person.position).split(";").slice(0, 2).join(";");
      if (!key) {
        return;
      }
      const group = groups.get(key) || [];
      group.push(person);
      groups.set(key, group);
    });
    groups.forEach(group => {
      if (group.length < 2) {
        return;
      }
      group.sort((a, b) => text(a.number).localeCompare(text(b.number)));
      group.forEach((person, index) => {
        const original = text(person.position).split(";").map(Number);
        const ring = Math.floor(index / 8) + 1;
        const angle = index % 8 * Math.PI / 4;
        const latitudeOffset = Math.sin(angle) * 0.000045 * ring;
        const longitudeScale = Math.max(0.2, Math.cos(original[1] * Math.PI / 180));
        const longitudeOffset = Math.cos(angle) * 0.000045 * ring / longitudeScale;
        person.rawPosition = person.position;
        person.position = `${original[0] + longitudeOffset};${original[1] + latitudeOffset};0`;
        person.positionAdjusted = true;
      });
    });
  }
  function mapLocations(rows, centers, employees) {
    const centersByCode = new Map(centers.map(center => [text(center.code), center]));
    const employeesByNumber = new Map(employees.map(employee => [text(employee.number), employee]));
    const locationsByCenter = new Map();
    const mapPersonnel = [];
    rows.forEach(row => {
      const code = text(row.CenterOffice) || text(row.CenterCode) || text(row.Center);
      const center = centersByCode.get(code) || {};
      const employee = employeesByNumber.get(text(row.PersonalNumber)) || {};
      const employeeZoneId = text(employee.zoneId);
      const zoneId = operationalZoneId(employeeZoneId && employeeZoneId !== "sin-zona" ? employeeZoneId : text(center.zoneId) || row.Zone);
      const latitudeCenter = coordinate(row.LatitudeCenter);
      const longitudeCenter = coordinate(row.LongitudeCenter, true);
      const hasCenterCoordinates = latitudeCenter !== null && longitudeCenter !== null && !(latitudeCenter === 0 && longitudeCenter === 0);
      if (code && hasCenterCoordinates && !locationsByCenter.has(code)) {
        locationsByCenter.set(code, {
          id: code.toLowerCase(),
          zoneId,
          name: text(center.name) || code,
          code,
          position: `${longitudeCenter};${latitudeCenter};0`,
          type: "Default",
          icon: "sap-icon://building",
          tooltip: `${text(center.name) || code} · ubicación proporcionada por SAP`
        });
      }
      const latitudeEmployee = coordinate(row.LatitudeEmp);
      const longitudeEmployee = coordinate(row.LongitudeEmp, true);
      const hasEmployeeCoordinates = latitudeEmployee !== null && longitudeEmployee !== null && !(latitudeEmployee === 0 && longitudeEmployee === 0);
      if (text(row.PersonalNumber)) {
        const name = text(row.FullName) || text(employee.name) || text(row.PersonalNumber);
        const geofence = mapGeofenceStatus(row, hasEmployeeCoordinates ? latitudeEmployee : null, hasEmployeeCoordinates ? longitudeEmployee : null, hasCenterCoordinates ? latitudeCenter : null, hasCenterCoordinates ? longitudeCenter : null);
        const distanceLabel = geofence.distance === null ? "Sin dato" : `${geofence.distance.toFixed(1)} m`;
        mapPersonnel.push({
          employeeId: `employee-${text(row.PersonalNumber)}`,
          number: text(row.PersonalNumber),
          name,
          initials: name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part.charAt(0)).join(""),
          zoneId,
          centerId: code.toLowerCase(),
          center: text(center.name) || text(employee.center) || code,
          position: hasEmployeeCoordinates ? `${longitudeEmployee};${latitudeEmployee};0` : "",
          hasCoordinates: hasEmployeeCoordinates,
          role: text(employee.role) || "Colaborador",
          locationStatus: geofence.label,
          type: geofence.type,
          state: geofence.state,
          lastLocation: text(row.LastSignal) || text(row.LastUpdate) || "Sin hora reportada",
          accuracy: distanceLabel,
          latitude: hasEmployeeCoordinates ? latitudeEmployee : null,
          longitude: hasEmployeeCoordinates ? longitudeEmployee : null,
          coordinatesText: hasEmployeeCoordinates ? `${latitudeEmployee.toFixed(6)}, ${longitudeEmployee.toFixed(6)}` : "Sin coordenadas registradas",
          tooltip: `${name} · ${geofence.label} · ${distanceLabel}`
        });
      }
    });
    separateOverlappingPersonnel(mapPersonnel);
    const centerList = Array.from(locationsByCenter.values());
    const zoneGroups = new Map();
    centerList.forEach(center => {
      const zoneId = text(center.zoneId);
      if (zoneId === "sin-zona") {
        return;
      }
      const group = zoneGroups.get(zoneId) || [];
      group.push(center);
      zoneGroups.set(zoneId, group);
    });
    const zoneIds = new Set([...Array.from(zoneGroups.keys()), ...mapPersonnel.map(person => text(person.zoneId)).filter(zoneId => zoneId && zoneId !== "sin-zona")]);
    const mapZones = Array.from(zoneIds).map(zoneId => {
      const group = zoneGroups.get(zoneId) || [];
      const personnelInZone = mapPersonnel.filter(person => person.zoneId === zoneId);
      const personnelWithCoordinates = personnelInZone.filter(person => person.hasCoordinates);
      const coordinateSources = group.length ? group : personnelWithCoordinates;
      const coordinates = coordinateSources.map(item => text(item.rawPosition || item.position).split(";").map(Number));
      if (!coordinates.length) {
        return null;
      }
      const longitude = coordinates.reduce((sum, item) => sum + item[0], 0) / coordinates.length;
      const latitude = coordinates.reduce((sum, item) => sum + item[1], 0) / coordinates.length;
      const visible = personnelWithCoordinates.length;
      return {
        id: zoneId,
        name: displayZone(zoneId),
        position: `${longitude};${latitude};0`,
        centerPosition: `${longitude};${latitude}`,
        zoomLevel: 6,
        text: zoneId.charAt(0).toUpperCase(),
        type: "Default",
        centers: group.length,
        users: personnelInZone.length,
        online: visible,
        tooltip: `${displayZone(zoneId)} · ${group.length} centros · ${visible} ubicaciones`
      };
    }).filter(Boolean);
    return {
      mapZones,
      mapCenters: centerList,
      mapPersonnel
    };
  }
  function mapOverview(zoneRows, indicators, centerRows, trendRows) {
    const groupedZones = new Map();
    zoneRows.forEach(row => {
      const key = operationalZoneId(row.Zone);
      if (key === "sin-zona") {
        return;
      }
      const group = groupedZones.get(key) || [];
      group.push(row);
      groupedZones.set(key, group);
    });
    const zones = OPERATIONAL_ZONES.map(configuredZone => {
      const zoneId = configuredZone.id;
      const rows = groupedZones.get(zoneId) || [];
      const first = rows[0] || {};
      const users = rows.reduce((sum, row) => sum + number(row.UsersCount), 0);
      const evaluated = rows.reduce((sum, row) => sum + number(row.EvaluatedCount), 0) || users;
      const present = rows.reduce((sum, row) => sum + number(row.PresentCount), 0);
      const late = rows.reduce((sum, row) => sum + number(row.LateCount), 0);
      const absent = rows.reduce((sum, row) => sum + number(row.AbsenceCount), 0);
      const outside = rows.reduce((sum, row) => sum + number(row.OutOfZoneCount), 0);
      const attendance = evaluated ? present * 100 / evaluated : 0;
      const inefficiency = evaluated ? (late + absent + outside) * 100 / evaluated : 0;
      const riskInfo = risk(inefficiency, first.RiskLevel);
      const zoneName = configuredZone.name;
      const explicitCenters = Math.max(...rows.map(row => number(row.CentersCount)), 0);
      const centers = explicitCenters || new Set(centerRows.filter(row => operationalZoneId(row.Zone) === zoneId && text(row.CenterCode)).map(row => text(row.CenterCode))).size;
      return {
        zoneId,
        zone: zoneName.replace(/^Zona\s+/i, ""),
        name: zoneName,
        centers,
        users,
        meta: `${centers} centros con registros · ${users} jornadas`,
        total: evaluated,
        present,
        late,
        absent,
        outside,
        attendance: attendance.toFixed(1),
        inefficiency: inefficiency.toFixed(1),
        incidentSummary: `${late} retardos · ${absent} ausencias · ${outside} fuera de zona`,
        inefficiencyText: `${inefficiency.toFixed(1)}% ineficiencia`,
        riskText: riskInfo.text,
        state: riskInfo.state,
        lateRate: evaluated ? late * 100 / evaluated : 0,
        absentRate: evaluated ? absent * 100 / evaluated : 0
      };
    });
    const indicator = (name, detail) => indicators.find(row => text(row.Indicator).toLowerCase() === name.toLowerCase() && (!detail || text(row.TextValues).toLowerCase() === detail.toLowerCase()));
    const attendance = indicator("Asistencia global");
    const late = indicator("Incidencias", "Retardos");
    const absent = indicator("Incidencias", "Ausencias");
    const outside = indicator("Incidencias", "Fuera de zona");
    const greatestRisk = indicator("Mayor riesgo");
    const gap = indicator("Brecha de meta");
    const priority = indicator("Prioridad del día");
    const incidentCount = number(late?.Numerator) + number(absent?.Numerator) + number(outside?.Numerator);
    const criticalCenters = centerRows.map(row => {
      const inefficiency = number(row.InefficiencyPct);
      const riskInfo = risk(inefficiency, row.RiskLevel);
      return {
        id: text(row.CenterCode).toLowerCase(),
        center: text(row.CenterOffice),
        zone: displayZone(row.Zone),
        incidents: number(row.IncidentCount) || number(row.LateCount) + number(row.AbsenceCount) + number(row.OutOfZoneCount),
        inefficiency: `${inefficiency.toFixed(1)}%`,
        attendance: `${number(row.AttendancePct).toFixed(1)}%`,
        status: riskInfo.text,
        state: riskInfo.state,
        total: number(row.EvaluatedCount) || number(row.UsersCount)
      };
    }).filter(row => row.total > 0).sort((a, b) => number(b.inefficiency) - number(a.inefficiency));
    return {
      zoneSummaries: zones,
      zoneInefficiency: zones.map(zone => ({
        zoneId: zone.zoneId,
        zone: zone.zone,
        lateRate: zone.lateRate,
        absentRate: zone.absentRate
      })),
      incidentTrend: trendRows.map(row => ({
        day: displayDate(row.TrendDate).slice(0, 5),
        late: number(row.LateCount),
        absent: number(row.AbsenceCount),
        outsideZone: number(row.OutOfZoneCount)
      })),
      criticalCenters,
      overviewSummary: {
        attendance: number(attendance?.ValueIndicator).toFixed(1),
        attendanceDescription: text(attendance?.TextValues) || "Sin datos evaluados",
        incidents: incidentCount,
        incidentsDescription: `${number(late?.Numerator)} retardos · ${number(absent?.Numerator)} ausencias · ${number(outside?.Numerator)} fuera de zona`,
        criticalZone: text(greatestRisk?.TextValues) || "Sin riesgo detectado",
        criticalZoneDescription: text(greatestRisk?.ValueIndicator) || "Indicador proporcionado por SAP",
        targetGap: text(gap?.ValueIndicator) || "0.0 pp",
        targetGapDescription: text(gap?.TextValues) || "Diferencia frente a la meta de 90%"
      },
      priorityText: text(priority?.TextValues) || "No hay prioridades de ineficiencia para revisar."
    };
  }
  async function request(name, call, errors) {
    try {
      return await call();
    } catch (error) {
      errors.push(`${name}: ${error instanceof Error ? error.message : String(error)}`);
      return [];
    }
  }
  async function loadMonitorData(periodType = "SEMANA 43", dateFrom = `${new Date().getFullYear()}0101`, dateTo = `${new Date().getFullYear()}1231`) {
    const api = new AttendanceApi();
    const errors = [];
    const periodFilter = [{
      field: "PeriodType",
      value: periodType
    }];
    const historyFilter = [{
      field: "DateFrom",
      value: dateFrom
    }, {
      field: "DateTo",
      value: dateTo
    }];
    const [zoneRows, indicators, centerRows, scheduleRows, rawHistoryRows, employeeRows, employeeSummaryRows, scheduleSummaryRows, trendRows, distributionRows, mapRows, centerCatalogRows, zoneAttendanceRows, baseRows, relationLaboralRows] = await Promise.all([request("ZoneSummarySet", () => api.getCollection("ZoneSummarySet", {
      filters: periodFilter
    }), errors), request("CriticalIndicatorsSet", () => api.getCollection("CriticalIndicatorsSet", {
      filters: periodFilter
    }), errors), request("CenterOfficeSummarySet", () => api.getCollection("CenterOfficeSummarySet", {
      filters: periodFilter
    }), errors), request("CatalogScheduleSet", () => api.getCollection("CatalogScheduleSet"), errors), request("AttendanceHistorySet", () => api.getCollection("AttendanceHistorySet", {
      filters: historyFilter
    }), errors), request("EmployeeSet", () => api.getCollection("EmployeeSet"), errors), request("EmployeeSummarySet", () => api.getCollection("EmployeeSummarySet"), errors), request("ScheduleSummarySet", () => api.getCollection("ScheduleSummarySet", {
      filters: periodFilter
    }), errors), request("IncidentTrendSet", () => api.getCollection("IncidentTrendSet", {
      filters: periodFilter
    }), errors), request("ScheduleDistributionSet", () => api.getCollection("ScheduleDistributionSet", {
      filters: periodFilter
    }), errors), request("GeneralMapUbicationsSet", () => api.getCollection("GeneralMapUbicationsSet"), errors), request("CenterOfficeSet", () => api.getCollection("CenterOfficeSet"), errors), request("ZoneAttendanceSet", () => api.getCollection("ZoneAttendanceSet"), errors), request("BasesSet", () => api.getCollection("BasesSet"), errors), request("RelationLaboralSet", () => api.getCollection("RelationLaboralSet"), errors)]);
    // El backend puede devolver jornadas fuera del rango solicitado. El filtrado
    // defensivo evita contaminar los totales mensuales y anuales de la interfaz.
    const historyRows = rawHistoryRows.filter(row => {
      const workDate = compactDate(row.WorkDate);
      return Boolean(workDate) && workDate >= dateFrom && workDate <= dateTo;
    });
    const scheduleSummary = scheduleSummaryRows[0] || {};
    const schedules = mapSchedules(scheduleRows, number(scheduleSummary.ActiveSchedules));
    const records = mapRecords(historyRows, schedules);
    const employees = mapEmployees(employeeRows, historyRows);
    const centers = mapCenters(centerRows, historyRows, employees);
    const locations = mapLocations(mapRows, centers, employees);
    const overview = mapOverview(zoneRows, indicators, centerRows, trendRows);
    const zones = [{
      id: "all",
      name: "Todas las zonas"
    }].concat(OPERATIONAL_ZONES.map(zone => ({
      id: zone.id,
      name: zone.name
    })));
    const effectiveStatusCatalog = ["Presente", "Retardo", "Ausente", "Incompleto", "Viaje de trabajo", "Vacaciones", "Paternidad", "Home office", "Fuera de zona"].map(status => ({
      key: status,
      text: status
    }));
    const laborStatusCatalog = [{
      key: "all",
      text: "Todos"
    }].concat(relationLaboralRows.map(row => ({
      key: text(row.RelationJob),
      text: text(row.RelationDescription) || text(row.RelationJob)
    })).filter(item => Boolean(item.key)));
    const employeeSummary = employeeSummaryRows[0] || {};
    const derivedActiveEmployees = employees.filter(employee => Boolean(employee.active)).length;
    const derivedInactiveEmployees = employees.length - derivedActiveEmployees;
    return {
      errors,
      data: {
        serviceState: {
          loading: false,
          live: true,
          periodType,
          errors
        },
        zones,
        statusCatalog: [{
          key: "all",
          text: "Todos"
        }].concat(effectiveStatusCatalog),
        laborStatusCatalog,
        centers,
        schedules,
        employees,
        records,
        userPerformanceHistory: [],
        configuration: {
          lateTolerance: 10,
          earlyEntry: 20,
          automaticAbsence: "10:00",
          refreshMinutes: 5
        },
        sapOverview: overview,
        sapZoneSummaries: zoneRows,
        sapCriticalIndicators: indicators,
        sapCenterSummaries: centerRows,
        sapScheduleDistribution: distributionRows,
        sapIncidentTrend: trendRows,
        sapScheduleSummary: scheduleSummaryRows,
        sapScheduleTypes: [],
        sapEmployees: employeeRows,
        sapEmployeeSummary: employeeSummaryRows,
        sapAttendanceHistory: historyRows,
        sapAttendanceHistoryRaw: rawHistoryRows,
        sapMapLocations: mapRows,
        sapCenterCatalog: centerCatalogRows,
        sapZoneAttendance: zoneAttendanceRows,
        sapBases: baseRows,
        sapZoneCatalog: zoneAttendanceRows,
        sapStatusCatalog: [],
        sapRelationLaboralCatalog: relationLaboralRows,
        mapZones: locations.mapZones,
        mapCenters: locations.mapCenters,
        mapPersonnel: locations.mapPersonnel,
        scheduleSummary: {
          active: number(scheduleSummary.ActiveSchedules),
          present: number(scheduleSummary.PresentCount),
          evaluated: number(scheduleSummary.EvaluatedCount),
          coverage: number(scheduleSummary.CoveragePct),
          absent: number(scheduleSummary.AbsenceCount),
          absencePct: number(scheduleSummary.AbsencePct)
        },
        employeeSummary: {
          total: number(employeeSummary.UsersCount) || employees.length,
          active: number(employeeSummary.ActiveCount) || derivedActiveEmployees,
          inactive: number(employeeSummary.InactiveCount) || derivedInactiveEmployees,
          centers: number(employeeSummary.CentersCount) || new Set(employees.map(employee => text(employee.centerId)).filter(Boolean)).size
        }
      }
    };
  }
  function emptyMonitorData(error) {
    return {
      serviceState: {
        loading: false,
        live: false,
        errors: error ? [error] : []
      },
      zones: [{
        id: "all",
        name: "Todas las zonas"
      }],
      statusCatalog: [{
        key: "all",
        text: "Todos"
      }, {
        key: "Presente",
        text: "Presente"
      }, {
        key: "Retardo",
        text: "Retardo"
      }, {
        key: "Ausente",
        text: "Ausente"
      }, {
        key: "Incompleto",
        text: "Incompleto"
      }, {
        key: "Viaje de trabajo",
        text: "Viaje de trabajo"
      }, {
        key: "Vacaciones",
        text: "Vacaciones"
      }, {
        key: "Paternidad",
        text: "Paternidad"
      }, {
        key: "Home office",
        text: "Home office"
      }, {
        key: "Fuera de zona",
        text: "Fuera de zona"
      }],
      laborStatusCatalog: [{
        key: "all",
        text: "Todos"
      }],
      centers: [],
      schedules: [],
      employees: [],
      records: [],
      userPerformanceHistory: [],
      sapOverview: null,
      sapZoneSummaries: [],
      sapCriticalIndicators: [],
      sapCenterSummaries: [],
      sapScheduleDistribution: [],
      sapIncidentTrend: [],
      sapScheduleSummary: [],
      sapScheduleTypes: [],
      sapEmployees: [],
      sapEmployeeSummary: [],
      sapAttendanceHistory: [],
      sapMapLocations: [],
      sapZoneCatalog: [],
      sapStatusCatalog: [],
      sapRelationLaboralCatalog: [],
      mapZones: [],
      mapCenters: [],
      mapPersonnel: [],
      employeeSummary: {
        total: 0,
        active: 0,
        inactive: 0,
        centers: 0
      },
      configuration: {
        lateTolerance: 10,
        earlyEntry: 20,
        automaticAbsence: "10:00",
        refreshMinutes: 5
      }
    };
  }
  var __exports = {
    __esModule: true
  };
  __exports.mapAttendanceRecords = mapAttendanceRecords;
  __exports.loadMonitorData = loadMonitorData;
  __exports.emptyMonitorData = emptyMonitorData;
  return __exports;
});
//# sourceMappingURL=MonitorData-dbg.js.map

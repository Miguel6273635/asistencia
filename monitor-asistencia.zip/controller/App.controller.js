sap.ui.define(["sap/ui/core/mvc/Controller"],i=>{"use strict";return i.extend("com.mitsu.monitorasistencia.monitorasistencia.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map